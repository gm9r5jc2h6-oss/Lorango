# Artifact Evaluation Guide

## Scope

This artifact supports the SDXL training claim only:

> A target-specific matched pair can be optimized with a training-time scaffold and exported as two ordinary static Diffusers LoRAs whose joint behavior uses SDXL's native GEGLU nonlinearity.

The package intentionally excludes SD3/FLUX experiments, paper-wide evaluation tables, generated figures, failed searches, and ready-to-deploy target pairs.

## Evaluation criteria

The release is organized around the usual top-tier artifact criteria:

| Criterion | Evidence in this package |
|---|---|
| Available | One versioned archive, checksums, no private absolute paths |
| Functional | CPU structural test and a one-step GPU end-to-end smoke test |
| Reproducible | Frozen defaults, seeds, package versions, input hashes, run metadata |
| Reusable | User-supplied cover LoRAs and prompt-pair dataset; documented schema |
| Auditable | Protocol, trace, calibration, compile record and output hashes |

## Hardware and time

- Quick structural checks: CPU, no SDXL model load.
- Input preflight: CPU, no SDXL model load.
- Functional smoke test: one CUDA GPU and a local SDXL Base 1.0 checkpoint.
- Full training: one CUDA GPU; 24 GB VRAM minimum, 48 GB recommended for the reference 512x512 configuration.

Runtime depends strongly on GPU, storage and prompt count. The artifact does not present a universal wall-clock estimate; record the timestamps and device information written to `RUN_METADATA.json`.

## A. Quick structural check

From the unpacked artifact root:

```bash
bash scripts/artifact_check.sh
```

Expected final line:

```text
ARTIFACT_CHECK=PASS
```

This verifies source syntax, required files, frozen asset hashes, all four carrier groups, example data and unit tests.

## B. Validate real inputs

Copy and edit the example config, then run:

```bash
python train_pair.py --config configs/my_pair.json --validate-only
```

Expected status: `VALID`. This checks paths, data splits, LoRA format, carrier capacity and module-key collisions without loading SDXL.

## C. One-step GPU functional test

The smoke test deliberately does **not** measure attack quality. It checks the entire executable path using one training and one calibration item:

```bash
python scripts/run_smoke.py \
  --config configs/my_pair.json \
  --output-dir /tmp/lorango_sdxl_smoke
```

It exercises:

1. SDXL and both cover LoRAs loading;
2. prompt encoding and latent state collection;
3. teacher-residual construction;
4. one backward/optimizer step;
5. checkpoint and calibration serialization;
6. static Signature/Payload compilation;
7. merged `modified_s.safetensors` and `modified_p.safetensors` export.

Expected files include `checkpoint_trained.pt`, `CALIBRATION.json`, `modified_s.safetensors`, `modified_p.safetensors`, `RUN_METADATA.json`, and `MANIFEST.json`.

## D. Full training

Use at least eight diverse train prompts and two disjoint calibration prompts:

```bash
bash scripts/train.sh configs/my_pair.json runs/my_pair.log
```

The default compiler runs only after all latent-space calibration gates pass. A failed gate is a valid, explicit result and does not silently produce a claimed successful pair.

## E. Verify exported format

The two `modified_*.safetensors` files load through the standard Diffusers API shown in `README.md`; custom inference hooks are not required. The run manifest records:

```json
{
  "ordinary_static_lora": true,
  "external_hook_at_inference": false,
  "external_detector_at_inference": false
}
```

## Recorded release verification

`VERIFICATION.json` records two completed checks on the reference server:

- an end-to-end one-step training/export/load test; and
- a byte-identical recompile of the frozen successful SDXL Pair-2 adapters.

These checks establish implementation fidelity. They do not replace evaluation of a newly chosen target behavior.

