# Security and ethics statement

This is an adversarial ML research artifact intended to study composition-triggered behavior in LoRA ecosystems and to support defenses, auditing and reproducibility.

Use only model checkpoints, adapters and compute resources for which you have authorization. Do not distribute a trained pair as benign without disclosure. Generated target pairs should remain inside the approved experimental scope and should be accompanied by their manifest and hashes.

The release excludes ready-to-deploy target pairs and paper-generated attack images. It provides training code, a non-deployable scaffold and a carrier catalogue so that authorized researchers can reproduce the method and evaluate detection and mitigation techniques.

