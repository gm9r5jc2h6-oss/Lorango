# LoRango SDXL Pair-Training Toolkit

Artifact release v1.1.0. Reviewers should begin with
[`ARTIFACT_EVALUATION.md`](ARTIFACT_EVALUATION.md).
The code release uses the Apache-2.0 license; model and adapter inputs retain
their respective upstream licenses.

This package contains only the **successful SDXL training and compilation path** used by the paper. It does not include evaluation suites, failed experiments, SD3/FLUX code, generated images, or ready-to-deploy trained attack pairs.

Given:

1. an SDXL base checkpoint;
2. a benign Signature cover LoRA;
3. a benign Payload cover LoRA; and
4. paired `base_prompt -> target_prompt` training examples,

the toolkit trains a new target-specific head and compiles it into two ordinary static LoRA files:

```text
modified_s.safetensors
modified_p.safetensors
```

At inference, each file preserves its benign cover behavior when loaded alone. The learned target behavior is activated by loading the matched pair together. Training uses forward hooks only as an optimization scaffold; the exported files contain no hooks, detector, scheduler callback, or external runtime component.

## 1. Environment

The reference environment is Python 3.10+, CUDA, and an NVIDIA GPU with at least 24 GB VRAM (48 GB is recommended for the default 512x512 protocol).

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
pip install --no-deps -e .
```

The reference server used:

```text
torch==2.6.0
diffusers==0.30.2
transformers==4.44.2
safetensors==0.4.5
numpy==1.26.4
accelerate==0.34.2
huggingface-hub==0.25.2
```

Equivalent `environment.yml` and `Dockerfile` specifications are included. Before using a GPU, run the dependency-free release check:

```bash
bash scripts/artifact_check.sh
```

## 2. Prepare data

Copy `examples/train_data.example.json`. Each split is a list of objects:

```json
{
  "train": [
    {
      "id": "train_001",
      "base_prompt": "a service robot in a museum lobby",
      "target_prompt": "a doberman dog in a museum lobby, same viewpoint and background"
    }
  ],
  "calibration": []
}
```

Recommended minimum: 8 diverse training prompts and 2 disjoint calibration prompts. The default protocol uses two train seeds and one calibration seed.

## 3. Configure

Copy `configs/train_pair.example.json` and edit these required paths:

```json
{
  "base_model": "/path/to/stable-diffusion-xl-base-1.0",
  "signature_cover_lora": "/path/to/benign_signature.safetensors",
  "payload_cover_lora": "/path/to/benign_payload.safetensors",
  "data_json": "/path/to/train_data.json",
  "output_dir": "/path/to/output/my_pair"
}
```

The two cover LoRAs must use Diffusers-style keys and must not already modify the carrier modules listed in `assets/carrier_catalog.json`. The command validates this before training.

## 4. Train and export

Run the full pipeline with one command:

```bash
python train_pair.py --config configs/my_pair.json
```

The logging wrapper preserves stdout/stderr for artifact review:

```bash
bash scripts/train.sh configs/my_pair.json runs/my_pair.log
```

To check paths, data, adapter keys, carrier availability, and configuration without loading SDXL:

```bash
python train_pair.py --config configs/my_pair.json --validate-only
```

To compile an existing trained checkpoint without retraining:

```bash
python train_pair.py \
  --config configs/my_pair.json \
  --compile-only /path/to/checkpoint_trained.pt
```

## 5. Outputs

The output directory contains:

```text
PROTOCOL.json                 frozen configuration and data split
RUN_METADATA.json             environment, seeds and exact input hashes
training_trace.json           optimization trace
checkpoint_trained.pt         non-deployable training state
CALIBRATION.json              held-out latent-space calibration
signature.safetensors         carrier-only Signature component
payload.safetensors           carrier-only Payload component
modified_s.safetensors        deployable Signature + benign cover
modified_p.safetensors        deployable Payload + benign cover
COMPILE.json                  selected layers, channels and output hashes
MANIFEST.json                 hashes, layers, scales, and final status
```

Only `modified_s.safetensors` and `modified_p.safetensors` are needed for ordinary inference.

## 6. Success criterion

By default, compilation proceeds only if calibration simultaneously satisfies:

- mean target-residual cosine >= 0.35;
- mean normalized RMSE <= 1.10;
- Signature-only relative drift <= 0.020; and
- Payload-only relative drift <= 0.020.

These are training-time latent checks, not paper test-set results. Keep validation and sealed-test prompts outside `train_data.json`.

## 7. Important reproducibility notes

- The bundled `assets/scaffold_init.pt` is a small, non-deployable optimization initialization. It is not a LoRA and cannot be used as an attack pair.
- `assets/carrier_catalog.json` is the frozen SDXL carrier catalogue used by the successful experiments.
- Set `training.use_warm_start_actions` to `false` to zero the initialized action matrices while retaining the learned reader scaffold.
- The exported adapters are ordinary static LoRAs and require no custom inference code.
- For a different SDXL implementation whose module names or dimensions differ from Diffusers SDXL Base 1.0, rebuild the carrier catalogue before use.
- `configs/train_pair.schema.json` defines the public configuration contract; unknown configuration keys are rejected.
- Training requests deterministic CUDA execution with fixed Python, NumPy and Torch seeds. Remaining platform-dependent behavior is disclosed in `RUN_METADATA.json`.

## 8. Repository map

```text
ARTIFACT_EVALUATION.md     reviewer checklist and expected results
docs/                      method, data, outputs and troubleshooting
configs/                   example config and JSON schema
examples/                  example prompt-pair dataset
assets/                    frozen non-deployable scaffold/catalogue
lorango_sdxl/              training and compilation implementation
scripts/                   structural check, logging wrapper and GPU smoke test
tests/                     CPU-side artifact unit tests
VERIFICATION.json          recorded reference-server verification
```

## 9. Minimal inference example

```python
from diffusers import StableDiffusionXLPipeline
import torch

pipe = StableDiffusionXLPipeline.from_pretrained(
    "/path/to/stable-diffusion-xl-base-1.0",
    torch_dtype=torch.float16,
    variant="fp16",
    use_safetensors=True,
).to("cuda")

pipe.load_lora_weights("/path/to/output", weight_name="modified_s.safetensors", adapter_name="S")
pipe.load_lora_weights("/path/to/output", weight_name="modified_p.safetensors", adapter_name="P")
pipe.set_adapters(["S", "P"], [1.0, 1.0])
image = pipe("your base prompt", num_inference_steps=30, guidance_scale=7.5).images[0]
image.save("sp_output.png")
```
