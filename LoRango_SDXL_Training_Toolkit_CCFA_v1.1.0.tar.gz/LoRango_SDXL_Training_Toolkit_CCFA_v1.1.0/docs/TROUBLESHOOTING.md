# Troubleshooting

## Cover/carrier collision

If preflight reports overlapping keys, the cover LoRA already modifies a selected GEGLU carrier module. Choose a non-overlapping cover or rebuild the carrier catalogue. Do not concatenate overlapping ranks without accounting for each adapter's alpha convention.

## CUDA out of memory

Use a less occupied GPU, reduce the 512x512 smoke test to 256x256, or reduce the number of cached prompt/seed cases. Do not change the paper configuration when reporting paper results.

## Calibration failure

Treat it as a failed target compilation, not a software error. First increase scene diversity, then optimization steps. Adjust carrier scales only on calibration data and keep validation/sealed prompts untouched.

## Different SDXL implementation

The frozen catalogue targets Diffusers SDXL Base 1.0 module names and dimensions. A checkpoint with a modified U-Net layout requires a newly scanned carrier catalogue.

