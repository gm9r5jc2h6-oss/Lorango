# Output contract

## Deployable files

Only these files are required by the inference user:

```text
modified_s.safetensors
modified_p.safetensors
```

They use Diffusers-style LoRA keys and load with the standard `load_lora_weights` API.

## Non-deployable audit files

| File | Purpose |
|---|---|
| `PROTOCOL.json` | Frozen inputs, split and hyperparameters |
| `RUN_METADATA.json` | Software/hardware versions and input hashes |
| `training_trace.json` | Per-update optimization trace |
| `checkpoint_trained.pt` | Training state used by the compiler |
| `CALIBRATION.json` | Held-out latent metrics and rows |
| `COMPILE.json` | Carrier layers, channels, scales and file hashes |
| `MANIFEST.json` | Final status and concise audit summary |

`checkpoint_trained.pt` is not an inference adapter and must not be presented as one.

