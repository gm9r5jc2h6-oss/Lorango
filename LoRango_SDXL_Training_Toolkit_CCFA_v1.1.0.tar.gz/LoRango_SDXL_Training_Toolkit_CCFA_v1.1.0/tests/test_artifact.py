from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from pathlib import Path

import torch

from lorango_sdxl.carrier import expected_carrier_keys, select_carriers
from lorango_sdxl.config import load_data


ROOT = Path(__file__).resolve().parents[1]


class ArtifactTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.scaffold = torch.load(
            ROOT / "assets" / "scaffold_init.pt", map_location="cpu", weights_only=False
        )

    def test_example_data(self) -> None:
        data = load_data(ROOT / "examples" / "train_data.example.json")
        self.assertEqual(len(data["train"]), 8)
        self.assertEqual(len(data["calibration"]), 2)

    def test_duplicate_ids_are_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bad.json"
            path.write_text(
                json.dumps(
                    {
                        "train": [["x", "base", "target"]],
                        "calibration": [["x", "base2", "target2"]],
                    }
                )
            )
            with self.assertRaisesRegex(ValueError, "duplicate"):
                load_data(path)

    def test_four_groups_are_disjoint(self) -> None:
        channels_by_block: dict[str, set[int]] = {}
        for group in range(4):
            config = {
                "carrier_catalog": str(ROOT / "assets" / "carrier_catalog.json"),
                "carrier": {"group_index": group, "exclude_layers": []},
            }
            selected = select_carriers(config, self.scaffold)
            self.assertEqual(len(selected), 5)
            self.assertEqual(len(expected_carrier_keys(selected)), 20)
            for row in selected:
                used = channels_by_block.setdefault(row["block"], set())
                current = set(row["channels"])
                self.assertFalse(used.intersection(current))
                used.update(current)

    def test_frozen_assets_match_manifest(self) -> None:
        manifest = json.loads((ROOT / "assets" / "ASSET_MANIFEST.json").read_text())
        for name, spec in manifest["assets"].items():
            digest = hashlib.sha256((ROOT / "assets" / name).read_bytes()).hexdigest()
            self.assertEqual(digest, spec["sha256"])


if __name__ == "__main__":
    unittest.main()

