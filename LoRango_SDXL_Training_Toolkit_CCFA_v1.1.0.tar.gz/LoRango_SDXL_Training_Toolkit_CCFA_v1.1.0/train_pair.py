#!/usr/bin/env python3
from lorango_sdxl.cli import main


if __name__ == "__main__":
    main()

