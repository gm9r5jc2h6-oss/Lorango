#!/usr/bin/env python3
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "README.md",
    "ARTIFACT_EVALUATION.md",
    "SECURITY_AND_ETHICS.md",
    "CITATION.cff",
    "LICENSE",
    "pyproject.toml",
    "requirements.txt",
    "configs/train_pair.example.json",
    "configs/train_pair.schema.json",
    "examples/train_data.example.json",
    "assets/scaffold_init.pt",
    "assets/carrier_catalog.json",
    "assets/ASSET_MANIFEST.json",
    "train_pair.py",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    missing = [name for name in REQUIRED if not (ROOT / name).is_file()]
    if missing:
        raise SystemExit(f"missing required files: {missing}")
    manifest = json.loads((ROOT / "assets" / "ASSET_MANIFEST.json").read_text())
    for name, spec in manifest["assets"].items():
        actual = sha256(ROOT / "assets" / name)
        if actual != spec["sha256"]:
            raise SystemExit(f"asset checksum mismatch: {name}: {actual}")
    for path in sorted(ROOT.rglob("*.py")):
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    for path in sorted(ROOT.rglob("*.json")):
        json.loads(path.read_text(encoding="utf-8"))
    print(
        json.dumps(
            {
                "status": "PASS",
                "required_files": len(REQUIRED),
                "verified_assets": len(manifest["assets"]),
                "python_sources": len(list(ROOT.rglob("*.py"))),
                "json_documents": len(list(ROOT.rglob("*.json"))),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
