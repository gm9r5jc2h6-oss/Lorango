from __future__ import annotations

import hashlib
import json
import os
import platform
import sys
from datetime import datetime, timezone
from importlib import metadata
from pathlib import Path
from typing import Any

import torch

from . import __version__
from .runtime import sha256


def _version(package: str) -> str | None:
    try:
        return metadata.version(package)
    except metadata.PackageNotFoundError:
        return None


def _canonical_hash(value: object) -> str:
    payload = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _base_model_identity(path_value: str) -> dict[str, Any]:
    path = Path(path_value)
    result: dict[str, Any] = {"path_or_id": path_value}
    if not path.exists():
        result["local"] = False
        return result
    result["local"] = True
    if path.is_file():
        result["sha256"] = sha256(path)
        result["bytes"] = path.stat().st_size
        return result
    metadata_files = [
        path / "model_index.json",
        path / "unet" / "config.json",
        path / "scheduler" / "scheduler_config.json",
        path / "text_encoder" / "config.json",
        path / "text_encoder_2" / "config.json",
        path / "vae" / "config.json",
    ]
    files = {}
    for item in metadata_files:
        if item.is_file():
            files[str(item.relative_to(path))] = sha256(item)
    result["metadata_files"] = files
    result["metadata_digest"] = _canonical_hash(files)
    return result


def build_run_metadata(config: dict[str, Any], mode: str) -> dict[str, Any]:
    device = str(config["device"])
    gpu = None
    if device.startswith("cuda") and torch.cuda.is_available():
        index = torch.device(device).index
        index = torch.cuda.current_device() if index is None else index
        properties = torch.cuda.get_device_properties(index)
        gpu = {
            "index": index,
            "name": properties.name,
            "total_memory_bytes": properties.total_memory,
            "compute_capability": f"{properties.major}.{properties.minor}",
        }
    inputs = {
        "base_model": _base_model_identity(config["base_model"]),
        "signature_cover_lora": {
            "path": config["signature_cover_lora"],
            "sha256": sha256(Path(config["signature_cover_lora"])),
        },
        "payload_cover_lora": {
            "path": config["payload_cover_lora"],
            "sha256": sha256(Path(config["payload_cover_lora"])),
        },
        "data_json": {
            "path": config["data_json"],
            "sha256": sha256(Path(config["data_json"])),
        },
        "scaffold_init": {
            "path": config["scaffold_init"],
            "sha256": sha256(Path(config["scaffold_init"])),
        },
        "carrier_catalog": {
            "path": config["carrier_catalog"],
            "sha256": sha256(Path(config["carrier_catalog"])),
        },
    }
    public_config = {key: value for key, value in config.items() if not key.startswith("_")}
    return {
        "schema_version": 1,
        "toolkit": "LoRango SDXL Pair-Training Toolkit",
        "toolkit_version": __version__,
        "mode": mode,
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "config_path": config.get("_config_path"),
        "config_sha256": _canonical_hash(public_config),
        "environment": {
            "python": sys.version.split()[0],
            "platform": platform.platform(),
            "torch": torch.__version__,
            "cuda_runtime": torch.version.cuda,
            "cudnn": torch.backends.cudnn.version(),
            "diffusers": _version("diffusers"),
            "transformers": _version("transformers"),
            "safetensors": _version("safetensors"),
            "numpy": _version("numpy"),
            "accelerate": _version("accelerate"),
            "huggingface_hub": _version("huggingface-hub"),
            "device": device,
            "gpu": gpu,
        },
        "determinism": {
            "requested": bool(config["training"].get("deterministic", True)),
            "fixed_seed": int(config["training"]["fixed_seed"]),
            "cublas_workspace_config": os.environ.get("CUBLAS_WORKSPACE_CONFIG"),
            "flash_sdp_enabled": torch.backends.cuda.flash_sdp_enabled(),
            "memory_efficient_sdp_enabled": torch.backends.cuda.mem_efficient_sdp_enabled(),
            "math_sdp_enabled": torch.backends.cuda.math_sdp_enabled(),
            "note": "When requested, training disables Flash/memory-efficient SDP and enables strict deterministic algorithms.",
        },
        "inputs": inputs,
    }
