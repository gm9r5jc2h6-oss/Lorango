from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any

from safetensors.torch import safe_open


PACKAGE_ROOT = Path(__file__).resolve().parents[1]

DEFAULTS: dict[str, Any] = {
    "device": "cuda:0",
    "local_files_only": True,
    "runtime": {
        "height": 512,
        "width": 512,
        "inference_steps": 30,
        "guidance_scale": 7.5,
        "record_steps": [0, 3, 7, 12, 18, 20],
    },
    "training": {
        "optimization_steps": 3000,
        "train_seeds": [2026087701, 2026087702],
        "calibration_seeds": [2026087791],
        "action_lr": 8e-4,
        "reader_lr": 2e-4,
        "train_readers": True,
        "use_warm_start_actions": True,
        "checkpoint_every": 500,
        "fixed_seed": 2026087714,
        "deterministic": True,
    },
    "carrier": {
        "group_index": 1,
        "gate_scale": 35.0,
        "reader_scale": 0.06,
        "action_scale": 0.45,
        "value_cancel_scale": 0.90,
        "exclude_layers": [],
    },
    "gates": {
        "mean_cosine_min": 0.35,
        "mean_nrmse_max": 1.10,
        "single_relative_drift_max": 0.020,
        "compile_on_failure": False,
    },
}

REQUIRED_PATHS = (
    "base_model",
    "signature_cover_lora",
    "payload_cover_lora",
    "data_json",
    "output_dir",
)


def _reject_unknown_keys(user: dict[str, Any]) -> None:
    allowed_top = set(DEFAULTS) | set(REQUIRED_PATHS) | {"scaffold_init", "carrier_catalog"}
    unknown_top = sorted(set(user) - allowed_top)
    if unknown_top:
        raise ValueError(f"unknown config keys: {unknown_top}")
    for section in ("runtime", "training", "carrier", "gates"):
        if section in user:
            if not isinstance(user[section], dict):
                raise TypeError(f"{section} must be a JSON object")
            unknown = sorted(set(user[section]) - set(DEFAULTS[section]))
            if unknown:
                raise ValueError(f"unknown {section} keys: {unknown}")


def _deep_update(base: dict[str, Any], update: dict[str, Any]) -> dict[str, Any]:
    for key, value in update.items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            _deep_update(base[key], value)
        else:
            base[key] = value
    return base


def _absolute(value: str, parent: Path) -> str:
    path = Path(value).expanduser()
    return str(path if path.is_absolute() else (parent / path).resolve())


def load_config(path: Path) -> dict[str, Any]:
    path = path.expanduser().resolve()
    user = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(user, dict):
        raise TypeError("top-level config must be a JSON object")
    _reject_unknown_keys(user)
    config = _deep_update(deepcopy(DEFAULTS), user)
    config["_config_path"] = str(path)
    missing = [key for key in REQUIRED_PATHS if not config.get(key)]
    if missing:
        raise ValueError(f"missing required config keys: {', '.join(missing)}")
    for key in ("base_model", "signature_cover_lora", "payload_cover_lora", "data_json", "output_dir"):
        config[key] = _absolute(str(config[key]), path.parent)
    config["scaffold_init"] = _absolute(
        str(config.get("scaffold_init", PACKAGE_ROOT / "assets" / "scaffold_init.pt")),
        path.parent,
    )
    config["carrier_catalog"] = _absolute(
        str(config.get("carrier_catalog", PACKAGE_ROOT / "assets" / "carrier_catalog.json")),
        path.parent,
    )
    validate_config(config)
    return config


def _adapter_keys(path: Path) -> set[str]:
    with safe_open(str(path), framework="pt", device="cpu") as handle:
        return set(handle.keys())


def validate_config(config: dict[str, Any]) -> None:
    for key in ("base_model", "signature_cover_lora", "payload_cover_lora", "data_json", "scaffold_init", "carrier_catalog"):
        path = Path(config[key])
        if not path.exists():
            raise FileNotFoundError(f"{key}: {path}")
    output = Path(config["output_dir"])
    if output.exists() and (output / "MANIFEST.json").exists():
        raise FileExistsError(f"completed output already exists: {output}")
    if Path(config["signature_cover_lora"]).resolve() == Path(
        config["payload_cover_lora"]
    ).resolve():
        raise ValueError("Signature and Payload cover LoRAs must be different files")
    runtime = config["runtime"]
    steps = int(runtime["inference_steps"])
    record = [int(v) for v in runtime["record_steps"]]
    if not record or record != sorted(set(record)) or record[0] < 0 or record[-1] >= steps:
        raise ValueError("runtime.record_steps must be sorted, unique, and within inference_steps")
    if int(runtime["height"]) % 8 or int(runtime["width"]) % 8:
        raise ValueError("runtime height and width must be divisible by 8")
    group = int(config["carrier"]["group_index"])
    if group not in (0, 1, 2, 3):
        raise ValueError("carrier.group_index must be one of 0, 1, 2, 3")
    for name in ("train_seeds", "calibration_seeds"):
        if not config["training"].get(name):
            raise ValueError(f"training.{name} cannot be empty")
    train_seeds = {int(value) for value in config["training"]["train_seeds"]}
    calibration_seeds = {
        int(value) for value in config["training"]["calibration_seeds"]
    }
    if train_seeds.intersection(calibration_seeds):
        raise ValueError("train_seeds and calibration_seeds must be disjoint")
    if int(config["training"]["optimization_steps"]) < 1:
        raise ValueError("training.optimization_steps must be >= 1")
    for key in ("action_lr", "reader_lr"):
        if float(config["training"][key]) <= 0:
            raise ValueError(f"training.{key} must be positive")
    for key in ("gate_scale", "reader_scale", "action_scale"):
        if float(config["carrier"][key]) <= 0:
            raise ValueError(f"carrier.{key} must be positive")
    for key in ("signature_cover_lora", "payload_cover_lora"):
        keys = _adapter_keys(Path(config[key]))
        if not any(name.endswith(".lora.down.weight") for name in keys):
            raise ValueError(f"{key} is not a Diffusers-style LoRA: {config[key]}")


def load_data(path: Path) -> dict[str, list[dict[str, str]]]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    if set(raw) != {"train", "calibration"}:
        raise ValueError("data JSON must contain exactly 'train' and 'calibration'")
    result: dict[str, list[dict[str, str]]] = {}
    seen: set[str] = set()
    for split in ("train", "calibration"):
        rows = []
        for index, row in enumerate(raw[split]):
            if isinstance(row, list) and len(row) == 3:
                item_id, base, target = row
            elif isinstance(row, dict):
                item_id = row.get("id")
                base = row.get("base_prompt", row.get("base"))
                target = row.get("target_prompt", row.get("teacher"))
            else:
                raise ValueError(f"invalid {split} row {index}: {row!r}")
            if not all(isinstance(value, str) and value.strip() for value in (item_id, base, target)):
                raise ValueError(f"empty or non-string field in {split} row {index}")
            if item_id in seen:
                raise ValueError(f"duplicate example id: {item_id}")
            seen.add(item_id)
            rows.append({"id": item_id, "base": base, "target": target})
        result[split] = rows
    if not result["train"] or not result["calibration"]:
        raise ValueError("both train and calibration splits must be non-empty")
    return result
