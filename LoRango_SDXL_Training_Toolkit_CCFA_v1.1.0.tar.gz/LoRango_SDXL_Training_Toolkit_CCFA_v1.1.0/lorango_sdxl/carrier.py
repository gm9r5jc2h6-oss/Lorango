from __future__ import annotations

import gc
import json
from pathlib import Path
from typing import Any

import torch
import torch.nn.functional as F
from safetensors.torch import load_file, save_file

from .runtime import resolve_module, sha256, write_json


BLOCK_SPECS = [
    ("d0_t0", "down_blocks.2.attentions.0.transformer_blocks.0"),
    ("d0_t3", "down_blocks.2.attentions.0.transformer_blocks.3"),
    ("d0_t6", "down_blocks.2.attentions.0.transformer_blocks.6"),
    ("d0_t8", "down_blocks.2.attentions.0.transformer_blocks.8"),
    ("d1_t1", "down_blocks.2.attentions.1.transformer_blocks.1"),
    ("d1_t7", "down_blocks.2.attentions.1.transformer_blocks.7"),
    ("mid_t1", "mid_block.attentions.0.transformer_blocks.1"),
    ("mid_t7", "mid_block.attentions.0.transformer_blocks.7"),
    ("u0a0_t1", "up_blocks.0.attentions.0.transformer_blocks.1"),
    ("u0a0_t7", "up_blocks.0.attentions.0.transformer_blocks.7"),
    ("u0a2_t1", "up_blocks.0.attentions.2.transformer_blocks.1"),
    ("u0a2_t7", "up_blocks.0.attentions.2.transformer_blocks.7"),
]

ELIGIBLE_NAMES = {
    "d0_t8",
    "d1_t1",
    "u0a0_t1",
    "u0a2_t1",
    "u0a2_t7",
}

UTILITY_ALPHA = 4.0


class TrainableGegluLayer:
    """Training-time differentiable scaffold for one SDXL GEGLU block."""

    def __init__(
        self,
        name: str,
        block,
        projection,
        output,
        state: dict[str, Any],
        device: str,
        use_warm_start_actions: bool,
    ) -> None:
        self.name = name
        self.signature_enabled = False
        self.payload_enabled = False
        self.signals = [int(value) for value in state["signals"]]
        self.references = [int(value) for value in state["references"]]
        gamma = block.norm3.weight.detach().float().to(device)
        beta = block.norm3.bias.detach().float().to(device)
        self.constant_reader = ((1.0 / gamma) / (beta / gamma).sum()).view(1, -1)
        self.value_readers = torch.nn.Parameter(state["value_readers"].float().to(device))
        initial_actions = state["actions"].float().to(device)
        if not use_warm_start_actions:
            initial_actions = torch.zeros_like(initial_actions)
        self.actions = torch.nn.Parameter(initial_actions)
        self.amplitudes = state["amplitudes"].float().to(device)
        self.projection_weight = projection.weight.detach().float().to(device)
        self.projection_bias = projection.bias.detach().float().to(device)
        self.output_weight = output.weight.detach().float().to(device)
        self.projection_handle = projection.register_forward_hook(self._projection_hook)
        self.output_handle = output.register_forward_hook(self._output_hook)

    def _projection_hook(self, _module, args, output):
        if not self.signature_enabled and not self.payload_enabled:
            return output
        x = args[0].float()
        constant = x @ self.constant_reader.T
        half = output.shape[-1] // 2
        result = output.float().clone()
        if self.payload_enabled:
            values = x @ self.value_readers.T
            for index, (signal, reference) in enumerate(zip(self.signals, self.references)):
                amplitude = self.amplitudes[index]
                for channel in (signal, reference):
                    native_value = x @ self.projection_weight[channel : channel + 1].T
                    result[..., channel : channel + 1] += (
                        values[..., index : index + 1]
                        - self.projection_bias[channel] * constant
                        - native_value
                    )
                    gate_row = half + channel
                    native_gate = x @ self.projection_weight[gate_row : gate_row + 1].T
                    result[..., gate_row : gate_row + 1] += (
                        (-0.5 * amplitude - self.projection_bias[gate_row]) * constant
                        - native_gate
                    )
        if self.signature_enabled:
            for index, signal in enumerate(self.signals):
                result[..., half + signal : half + signal + 1] += (
                    self.amplitudes[index] * constant
                )
        return result.to(output.dtype)

    def _output_hook(self, _module, args, output):
        if not self.payload_enabled:
            return output
        values = args[0].float()
        native = torch.zeros_like(output, dtype=torch.float32)
        interaction = torch.zeros_like(output, dtype=torch.float32)
        for index, (signal, reference) in enumerate(zip(self.signals, self.references)):
            native = native + (
                values[..., signal : signal + 1]
                * self.output_weight[:, signal].view(1, 1, -1)
                + values[..., reference : reference + 1]
                * self.output_weight[:, reference].view(1, 1, -1)
            )
            interaction = interaction + (
                values[..., signal : signal + 1]
                - values[..., reference : reference + 1]
            ) @ self.actions[:, index : index + 1].T
        return output + (interaction - native).to(output.dtype)

    def state(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "signals": self.signals,
            "references": self.references,
            "amplitudes": self.amplitudes.detach().cpu(),
            "value_readers": self.value_readers.detach().cpu(),
            "actions": self.actions.detach().cpu(),
            "constant_reader": self.constant_reader.detach().cpu(),
        }

    def close(self) -> None:
        self.projection_handle.remove()
        self.output_handle.remove()


class TrainablePair:
    def __init__(self, layers: list[TrainableGegluLayer]) -> None:
        self.layers = layers

    def enable(self, signature: bool, payload: bool) -> None:
        for layer in self.layers:
            layer.signature_enabled = bool(signature)
            layer.payload_enabled = bool(payload)

    def state(self, training_step: int) -> dict[str, Any]:
        return {
            "training_step": int(training_step),
            "layers": [layer.state() for layer in self.layers],
        }

    def close(self) -> None:
        for layer in self.layers:
            layer.close()


def make_trainable_pair(pipe, checkpoint: dict[str, Any], config: dict[str, Any]) -> TrainablePair:
    by_name = {layer["name"]: layer for layer in checkpoint["layers"]}
    missing = [name for name, _block in BLOCK_SPECS if name not in by_name]
    if missing:
        raise ValueError(f"scaffold is missing layers: {missing}")
    layers = []
    for name, block_name in BLOCK_SPECS:
        block = resolve_module(pipe.unet, block_name)
        projection = resolve_module(pipe.unet, f"{block_name}.ff.net.0.proj")
        output = resolve_module(pipe.unet, f"{block_name}.ff.net.2")
        layers.append(
            TrainableGegluLayer(
                name,
                block,
                projection,
                output,
                by_name[name],
                config["device"],
                bool(config["training"]["use_warm_start_actions"]),
            )
        )
    return TrainablePair(layers)


def load_catalog(path: Path) -> dict[str, Any]:
    catalog = json.loads(path.read_text(encoding="utf-8"))
    if "corrected_candidates_by_block" not in catalog:
        raise ValueError(f"invalid carrier catalog: {path}")
    return catalog


def select_carriers(config: dict[str, Any], checkpoint: dict[str, Any]) -> list[dict[str, Any]]:
    catalog = load_catalog(Path(config["carrier_catalog"]))
    source_by_name = {layer["name"]: layer for layer in checkpoint["layers"]}
    group = int(config["carrier"]["group_index"])
    excluded = set(config["carrier"].get("exclude_layers", []))
    selections = []
    for name, block in BLOCK_SPECS:
        if name not in ELIGIBLE_NAMES or name in excluded:
            continue
        if name not in source_by_name:
            raise ValueError(f"trained checkpoint is missing {name}")
        qualified = catalog["corrected_candidates_by_block"][block]["qualified"]
        selected = qualified[group * 4 : group * 4 + 4]
        if len(selected) != 4:
            raise ValueError(
                f"carrier group {group} is unavailable for {name}: only {len(qualified)} candidates"
            )
        amplitudes = source_by_name[name]["amplitudes"].float()[:4]
        interactions = torch.tensor(
            [max(float(row["interaction_median"]), 1e-6) for row in selected],
            dtype=torch.float32,
        )
        selections.append(
            {
                "name": name,
                "block": block,
                "channels": [int(row["channel"]) for row in selected],
                "action_normalizers": ((0.5 * amplitudes) / interactions).tolist(),
                "candidate_rows": selected,
            }
        )
    if not selections:
        raise ValueError("all eligible carrier layers were excluded")
    return selections


def expected_carrier_keys(selections: list[dict[str, Any]]) -> set[str]:
    keys: set[str] = set()
    for selected in selections:
        prefix = f"unet.{selected['block']}"
        for module in ("ff.net.0.proj", "ff.net.2"):
            keys.add(f"{prefix}.{module}.lora.down.weight")
            keys.add(f"{prefix}.{module}.lora.up.weight")
    return keys


def validate_cover_collisions(config: dict[str, Any], checkpoint: dict[str, Any]) -> None:
    expected = expected_carrier_keys(select_carriers(config, checkpoint))
    for label, key in (
        ("Signature", "signature_cover_lora"),
        ("Payload", "payload_cover_lora"),
    ):
        cover = load_file(config[key])
        collision = expected.intersection(cover)
        if collision:
            sample = sorted(collision)[:4]
            raise ValueError(
                f"{label} cover LoRA overlaps carrier modules; choose a cover without these keys: {sample}"
            )


def _scaled_up(value: torch.Tensor, rank: int) -> torch.Tensor:
    return value * (float(rank) / UTILITY_ALPHA)


def _merge(cover_path: Path, carrier_path: Path, destination: Path) -> None:
    cover = load_file(str(cover_path))
    carrier = load_file(str(carrier_path))
    collision = set(cover).intersection(carrier)
    if collision:
        raise RuntimeError(f"cover/carrier key collision: {sorted(collision)[:4]}")
    state = {key: value.clone() for key, value in cover.items()}
    state.update({key: value.clone() for key, value in carrier.items()})
    save_file(state, str(destination), metadata={"format": "pt"})


@torch.no_grad()
def compile_pair(pipe, checkpoint_path: Path, config: dict[str, Any]) -> dict[str, Any]:
    output_dir = Path(config["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    source_by_name = {layer["name"]: layer for layer in checkpoint["layers"]}
    selections = select_carriers(config, checkpoint)
    validate_cover_collisions(config, checkpoint)

    module_shapes = {}
    for selected in selections:
        block_name = selected["block"]
        block = resolve_module(pipe.unet, block_name)
        projection = resolve_module(pipe.unet, f"{block_name}.ff.net.0.proj")
        output = resolve_module(pipe.unet, f"{block_name}.ff.net.2")
        gamma = block.norm3.weight.detach().float().cpu()
        beta = block.norm3.bias.detach().float().cpu()
        channels = selected["channels"]
        module_shapes[block_name] = {
            "projection_rows": int(projection.weight.shape[0]),
            "projection_width": int(projection.weight.shape[1]),
            "output_width": int(output.weight.shape[1]),
            "constant_reader": ((1.0 / gamma) / (beta / gamma).sum()).view(-1),
            "native_value_rows": projection.weight.detach().float().cpu()[channels, :],
            "native_columns": output.weight.detach().float().cpu()[:, channels],
        }

    carrier_cfg = config["carrier"]
    signature_state: dict[str, torch.Tensor] = {}
    payload_state: dict[str, torch.Tensor] = {}
    layer_manifest = []
    for selected in selections:
        name = selected["name"]
        block_name = selected["block"]
        prefix = f"unet.{block_name}"
        channels = selected["channels"]
        rank = len(channels)
        shapes = module_shapes[block_name]
        half = shapes["projection_rows"] // 2
        source = source_by_name[name]
        readers = source["value_readers"].float()[:rank].clone()
        readers *= float(carrier_cfg["reader_scale"])
        normalizers = torch.tensor(selected["action_normalizers"], dtype=torch.float32)
        actions = source["actions"].float()[:, :rank].clone()
        # Keep the multiplication order identical to the frozen successful
        # compiler; changing it alters float32 bytes at ~1e-9 even though the
        # numerical operation is equivalent.
        actions = actions * normalizers.view(1, -1)
        actions = actions * float(carrier_cfg["action_scale"])

        signature_projection_rank = 1 + rank
        signature_projection_down = torch.zeros(
            (signature_projection_rank, shapes["projection_width"]), dtype=torch.float32
        )
        signature_projection_down[0] = shapes["constant_reader"]
        signature_projection_down[1:] = shapes["native_value_rows"]
        signature_projection_up = torch.zeros(
            (shapes["projection_rows"], signature_projection_rank), dtype=torch.float32
        )
        for index, channel in enumerate(channels):
            signature_projection_up[half + channel, 0] = (
                4.0 * float(carrier_cfg["gate_scale"])
            )
            signature_projection_up[channel, index + 1] = -float(
                carrier_cfg["value_cancel_scale"]
            )
        signature_projection_up = _scaled_up(
            signature_projection_up, signature_projection_rank
        )

        signature_output_down = torch.zeros((rank, shapes["output_width"]), dtype=torch.float32)
        payload_output_down = torch.zeros((rank, shapes["output_width"]), dtype=torch.float32)
        payload_projection_up = torch.zeros((shapes["projection_rows"], rank), dtype=torch.float32)
        for index, channel in enumerate(channels):
            signature_output_down[index, channel] = 1.0
            payload_output_down[index, channel] = 1.0
            payload_projection_up[channel, index] = 1.0

        signature_state.update(
            {
                f"{prefix}.ff.net.0.proj.lora.down.weight": signature_projection_down.contiguous(),
                f"{prefix}.ff.net.0.proj.lora.up.weight": signature_projection_up.contiguous(),
                f"{prefix}.ff.net.2.lora.down.weight": signature_output_down.contiguous(),
                f"{prefix}.ff.net.2.lora.up.weight": _scaled_up(
                    -shapes["native_columns"], rank
                ).contiguous(),
            }
        )
        payload_state.update(
            {
                f"{prefix}.ff.net.0.proj.lora.down.weight": readers.contiguous(),
                f"{prefix}.ff.net.0.proj.lora.up.weight": _scaled_up(
                    payload_projection_up, rank
                ).contiguous(),
                f"{prefix}.ff.net.2.lora.down.weight": payload_output_down.contiguous(),
                f"{prefix}.ff.net.2.lora.up.weight": _scaled_up(actions, rank).contiguous(),
            }
        )
        layer_manifest.append(
            {
                "name": name,
                "block": block_name,
                "channels": channels,
                "action_normalizers": selected["action_normalizers"],
            }
        )

    signature_path = output_dir / "signature.safetensors"
    payload_path = output_dir / "payload.safetensors"
    modified_s = output_dir / "modified_s.safetensors"
    modified_p = output_dir / "modified_p.safetensors"
    save_file(signature_state, str(signature_path), metadata={"format": "pt"})
    save_file(payload_state, str(payload_path), metadata={"format": "pt"})
    _merge(Path(config["signature_cover_lora"]), signature_path, modified_s)
    _merge(Path(config["payload_cover_lora"]), payload_path, modified_p)
    result = {
        "format": "ordinary static Diffusers LoRA",
        "external_hook_at_inference": False,
        "external_detector_at_inference": False,
        "checkpoint": str(checkpoint_path),
        "carrier_group": int(carrier_cfg["group_index"]),
        "scales": {
            key: float(carrier_cfg[key])
            for key in ("gate_scale", "reader_scale", "action_scale", "value_cancel_scale")
        },
        "layers": layer_manifest,
        "files": {
            path.name: {"path": str(path), "sha256": sha256(path), "bytes": path.stat().st_size}
            for path in (signature_path, payload_path, modified_s, modified_p)
        },
    }
    write_json(output_dir / "COMPILE.json", result)
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    return result
