from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import torch

from . import __version__
from .carrier import (
    compile_pair,
    select_carriers,
    validate_cover_collisions,
)
from .config import load_config, load_data
from .provenance import build_run_metadata
from .runtime import load_pipe, sha256, write_json
from .training import cleanup_pipe, configure_determinism, train_head


def _protocol(config: dict[str, Any], data: dict[str, list[dict[str, str]]]) -> dict[str, Any]:
    safe_config = json.loads(json.dumps(config))
    return {
        "toolkit": "LoRango SDXL Pair-Training Toolkit",
        "version": __version__,
        "method": (
            "multi-layer native-GEGLU carrier with per-layer constant gating, "
            "native value cancellation, and native output subtraction"
        ),
        "config": safe_config,
        "data": data,
        "train_count": len(data["train"]),
        "calibration_count": len(data["calibration"]),
        "validation_or_sealed_data_used": False,
        "status": "FROZEN_BEFORE_TRAINING",
    }


def validate_only(config: dict[str, Any], data: dict[str, list[dict[str, str]]]) -> dict[str, Any]:
    scaffold = torch.load(config["scaffold_init"], map_location="cpu", weights_only=False)
    selections = select_carriers(config, scaffold)
    validate_cover_collisions(config, scaffold)
    warnings = []
    if len(data["train"]) < 8:
        warnings.append("fewer than 8 training prompts; cross-scene generalization may be weak")
    if len(data["calibration"]) < 2:
        warnings.append("fewer than 2 calibration prompts; gate estimates will be noisy")
    result = {
        "status": "VALID",
        "train_examples": len(data["train"]),
        "calibration_examples": len(data["calibration"]),
        "train_cases": len(data["train"]) * len(config["training"]["train_seeds"]),
        "calibration_cases": len(data["calibration"])
        * len(config["training"]["calibration_seeds"]),
        "carrier_group": int(config["carrier"]["group_index"]),
        "carrier_layers": [
            {"name": row["name"], "block": row["block"], "channels": row["channels"]}
            for row in selections
        ],
        "cover_files": {
            "signature": {
                "path": config["signature_cover_lora"],
                "sha256": sha256(Path(config["signature_cover_lora"])),
            },
            "payload": {
                "path": config["payload_cover_lora"],
                "sha256": sha256(Path(config["payload_cover_lora"])),
            },
        },
        "warnings": warnings,
    }
    return result


def _write_manifest(
    config: dict[str, Any],
    status: str,
    checkpoint: Path,
    calibration: dict[str, Any] | None,
    gates: dict[str, bool] | None,
    compilation: dict[str, Any] | None,
) -> dict[str, Any]:
    result = {
        "toolkit": "LoRango SDXL Pair-Training Toolkit",
        "toolkit_version": __version__,
        "status": status,
        "ordinary_static_lora": compilation is not None,
        "external_hook_at_inference": False,
        "external_detector_at_inference": False,
        "checkpoint": {
            "path": str(checkpoint),
            "sha256": sha256(checkpoint),
            "deployable": False,
        },
        "gates": gates,
        "calibration_summary": None
        if calibration is None
        else {key: value for key, value in calibration.items() if key != "rows"},
        "compilation": compilation,
    }
    write_json(Path(config["output_dir"]) / "MANIFEST.json", result)
    return result


def run_training(config: dict[str, Any], data: dict[str, list[dict[str, str]]]) -> dict[str, Any]:
    output_dir = Path(config["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    configure_determinism(config)
    write_json(output_dir / "PROTOCOL.json", _protocol(config, data))
    write_json(output_dir / "RUN_METADATA.json", build_run_metadata(config, "train"))
    pipe = load_pipe(config)
    try:
        checkpoint, calibration, gates = train_head(pipe, config, data)
        passed = all(gates.values())
        compilation = None
        status = "PASS" if passed else "TRAINING_GATE_FAILED"
        if passed or bool(config["gates"].get("compile_on_failure", False)):
            pipe.unload_lora_weights()
            compilation = compile_pair(pipe, checkpoint, config)
            if not passed:
                status = "COMPILED_WITH_FAILED_TRAINING_GATES"
        return _write_manifest(
            config, status, checkpoint, calibration, gates, compilation
        )
    finally:
        cleanup_pipe(pipe)


def run_compile_only(config: dict[str, Any], checkpoint: Path) -> dict[str, Any]:
    checkpoint = checkpoint.expanduser().resolve()
    if not checkpoint.exists():
        raise FileNotFoundError(checkpoint)
    Path(config["output_dir"]).mkdir(parents=True, exist_ok=True)
    write_json(
        Path(config["output_dir"]) / "RUN_METADATA.json",
        build_run_metadata(config, "compile_only"),
    )
    state = torch.load(checkpoint, map_location="cpu", weights_only=False)
    validate_cover_collisions(config, state)
    pipe = load_pipe(config)
    try:
        compilation = compile_pair(pipe, checkpoint, config)
        return _write_manifest(
            config,
            "COMPILED_WITHOUT_CALIBRATION",
            checkpoint,
            None,
            None,
            compilation,
        )
    finally:
        cleanup_pipe(pipe)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Train and compile one matched SDXL dual-LoRA pair."
    )
    parser.add_argument("--config", type=Path, required=True, help="training JSON config")
    parser.add_argument(
        "--validate-only",
        action="store_true",
        help="validate inputs and carrier layout without loading SDXL",
    )
    parser.add_argument(
        "--compile-only",
        type=Path,
        metavar="CHECKPOINT",
        help="skip optimization and compile an existing checkpoint",
    )
    return parser


def main() -> None:
    args = build_parser().parse_args()
    if args.validate_only and args.compile_only:
        raise SystemExit("--validate-only and --compile-only are mutually exclusive")
    config = load_config(args.config)
    data = load_data(Path(config["data_json"]))
    if args.validate_only:
        result = validate_only(config, data)
    elif args.compile_only:
        result = run_compile_only(config, args.compile_only)
    else:
        result = run_training(config, data)
    print(json.dumps(result, indent=2, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
